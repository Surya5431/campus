import React from "react";
import CampusNavigator from "./CampusNavigator";

export default function App() {
  return <CampusNavigator />;
}
